import json
import sys

files = [
    r"C:\Users\ccc\.cursor\projects\c-Users-ccc-Popcorn-Project-Prototype\agent-tools\9565a7df-34e5-4bbd-b2e6-b991033eb7c1.txt",
    r"C:\Users\ccc\.cursor\projects\c-Users-ccc-Popcorn-Project-Prototype\agent-tools\1d70d2d8-ace7-4361-80ca-ea5be11143e2.txt",
    r"C:\Users\ccc\.cursor\projects\c-Users-ccc-Popcorn-Project-Prototype\agent-tools\05b7e9fc-6ac6-4625-8419-c715cd919b6b.txt",
]


def walk(node, parent=None):
    if isinstance(node, dict):
        node["_parent"] = parent
        children = node.get("children", [])
        for child in children:
            walk(child, node)
    elif isinstance(node, list):
        for item in node:
            walk(item, parent)


def find_frames(node, pattern, frames=None):
    if frames is None:
        frames = {}
    if isinstance(node, dict):
        name = node.get("name", "")
        if node.get("type") == "FRAME" and pattern in name:
            frames[name] = node
        for child in node.get("children", []):
            find_frames(child, pattern, frames)
    elif isinstance(node, list):
        for item in node:
            find_frames(item, pattern, frames)
    return frames


def collect_texts(node, texts=None):
    if texts is None:
        texts = []
    if isinstance(node, dict):
        if node.get("type") == "TEXT" and "characters" in node:
            texts.append(
                {
                    "id": node["id"],
                    "text": node["characters"],
                    "y": node.get("absoluteBoundingBox", {}).get("y", 0),
                    "x": node.get("absoluteBoundingBox", {}).get("x", 0),
                }
            )
        for child in node.get("children", []):
            collect_texts(child, texts)
    return texts


def find_image_rectangles(node, images=None):
    if images is None:
        images = []
    if isinstance(node, dict):
        fills = node.get("fills", [])
        has_image = any(
            isinstance(f, dict) and f.get("type") == "IMAGE" for f in fills
        )
        if has_image and node.get("type") in ("RECTANGLE", "INSTANCE"):
            images.append(
                {
                    "id": node["id"],
                    "name": node.get("name", ""),
                    "type": node.get("type"),
                    "y": node.get("absoluteBoundingBox", {}).get("y", 0),
                    "x": node.get("absoluteBoundingBox", {}).get("x", 0),
                }
            )
        for child in node.get("children", []):
            find_image_rectangles(child, images)
    return images


def parse_borrow_select(frame):
    texts = collect_texts(frame)
    images = find_image_rectangles(frame)

    # Product names and prices from Group nodes
    products = []
    price_pattern = "월"
    product_texts = [
        t
        for t in texts
        if t["text"].startswith("월 ") or (
            not t["text"].startswith("월")
            and "원" not in t["text"]
            and t["text"]
            not in {
                "대여 가능",
                "전체",
                "소형가전",
                "소형가구",
                "계절용품",
                "생활용품",
                "대여하기",
                "다음",
                "홈",
                "보관 신청",
                "예약/신청",
                "대여",
                "마이페이지",
                "대여할 물품을",
                "선택해주세요",
                "대여 물품 선택",
            }
            and len(t["text"]) < 25
            and "대여" not in t["text"]
            and "선택" not in t["text"]
            and "물품" not in t["text"]
        )
    ]

  # Group by y position - pairs of name + price
    prices = [t for t in texts if t["text"].startswith("월 ")]
    names = []
    for t in texts:
        txt = t["text"]
        if txt in [
            "모니터 24인치",
            "의자",
            "스탠드 조명",
            "접이식 테이블",
            "선풍기(화이트)",
            "캐리어",
        ]:
            names.append(t)

    # Map images to products by y proximity
    card_images = sorted(
        [i for i in images if i["type"] == "INSTANCE" and "Component" in i["name"]],
        key=lambda x: (x["y"], x["x"]),
    )

    name_price_pairs = sorted(zip(names, prices), key=lambda x: x[0]["y"])

    category_map = {
        "모니터 24인치": "소형가전",
        "선풍기(화이트)": "계절용품",
        "의자": "소형가구",
        "캐리어": "생활용품",
        "스탠드 조명": "생활용품",
        "접이식 테이블": "소형가구",
    }

    detail_map = {
        "모니터 24인치": "3-02_borrow_detail11",
        "선풍기(화이트)": "3-02_borrow_detail01",
        "의자": "3-02_borrow_detail02",
        "캐리어": "3-02_borrow_detail03",
        "스탠드 조명": "3-02_borrow_detail04",
        "접이식 테이블": "3-02_borrow_detail05",
    }

    for i, (name_t, price_t) in enumerate(name_price_pairs):
        img_id = card_images[i]["id"] if i < len(card_images) else None
        products.append(
            {
                "name": name_t["text"],
                "price": price_t["text"],
                "category": category_map.get(name_t["text"], ""),
                "imageNodeId": img_id,
                "detailFrameName": detail_map.get(name_t["text"], ""),
            }
        )

    return products


def parse_borrow_detail(frame):
    texts = collect_texts(frame)
    images = find_image_rectangles(frame)

    text_by_content = {t["text"]: t for t in texts}

    # Find product name (after '제품 이름' label)
    product_name = None
    description = None
    rental_period = None
    price = None
    deposit = None

    for t in texts:
        txt = t["text"]
        if txt in [
            "모니터 24인치",
            "의자",
            "스탠드 조명",
            "접이식 테이블",
            "선풍기(화이트)",
            "캐리어",
        ]:
            product_name = txt
        if "구매" in txt or "삼성" in txt or "사무" in txt or "여행" in txt or "LED" in txt or "접이" in txt:
            description = txt
        if re_match_date_range(txt):
            rental_period = txt
        if txt.startswith("월 ") and "원" in txt and "~" not in txt:
            price = txt
        if "보증금" in txt or (txt.startswith("₩") and "보증" not in txt):
            pass

    # More robust parsing by y-order after labels
    sorted_texts = sorted(
        [t for t in texts if t["text"] not in {"제품 이름", "제품 설명", "대여 가능 기간", "대여 가격 ", "대여 가격", "대여하기", "홈", "보관 신청", "예약/신청", "대여", "마이페이지", "대여 가능한 물품의", "상세 설명을 확인해주세요", "대여 물품 상세정보"}],
        key=lambda x: x["y"],
    )

    img = next((i for i in images if i["type"] == "INSTANCE"), None)
    if not img:
        img = next((i for i in images if "Component" in i.get("name", "")), None)

    return {
        "frameName": frame.get("name"),
        "frameId": frame.get("id"),
        "productName": product_name,
        "description": description,
        "rentalPeriod": rental_period,
        "price": price,
        "deposit": deposit,
        "imageNodeId": img["id"] if img else None,
        "allTexts": [(t["text"], t["y"]) for t in sorted_texts],
    }


def re_match_date_range(txt):
    import re
    return bool(re.match(r"\d{4}\.\d{2}\.\d{2}", txt))


# Main extraction
frame_map = {}
select_frames = {}
detail_frames = {}

for fpath in files:
    with open(fpath, "r", encoding="utf-8") as fh:
        data = json.load(fh)

    for pattern, store in [("borrow_select", select_frames), ("borrow_detail", detail_frames)]:
        found = find_frames(data, pattern)
        for name, frame in found.items():
            if name not in store:
                store[name] = frame
            frame_map[name] = frame["id"]

# Also add other frames from file 1
for name in ["3-03_borrow_price", "3-02_borrow_detail11"]:
    pass

print("=== FRAME MAP ===")
print(json.dumps(frame_map, ensure_ascii=False, indent=2))

print("\n=== BORROW SELECT ===")
for name, frame in sorted(select_frames.items()):
    print(f"\n{name} ({frame['id']}):")
    products = parse_borrow_select(frame)
    print(json.dumps(products, ensure_ascii=False, indent=2))

print("\n=== BORROW DETAIL ===")
for name, frame in sorted(detail_frames.items()):
    result = parse_borrow_detail(frame)
    print(f"\n{name}:")
    print(json.dumps({k: v for k, v in result.items() if k != "allTexts"}, ensure_ascii=False, indent=2))
    print("  allTexts:", result.get("allTexts"))
