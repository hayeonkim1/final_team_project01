/**
 * Figma prototype — frame PNG + transparent hotspots
 * Final_project_prototype / final_teamproject 3 jw
 */
const screenHistory = [];

const FIGMA_TO_SLUG = {
  "334:5709": "1_home",
  "334:5673": "1_02_explain",
  "334:5581": "1_03_situation",
  "334:5416": "1_04_search_place01",
  "334:5307": "1_06_cabinet_select",
  "334:5249": "1_07_service_select",
  "334:5191": "1_07_service_select_01",
  "334:5133": "1_07_service_select_02",
  "334:5059": "1_08_address",
  "334:4948": "1_09_lending_service_select",
  "334:4850": "1_10_store_price",
  "334:4813": "1_11",
  "334:4753": "2_menu",
  "334:4716": "2_01_product_upload01",
  "334:4631": "2_02_product_upload02",
  "334:4585": "2_03_product_upload03",
  "334:4495": "2_04_lending_info",
  "334:4458": "2_05_lending_complete",
  "334:3948": "3_01_borrow_select_전체",
  "334:4050": "3_01_borrow_select_소형가전",
  "334:4152": "3_01_borrow_select_소형가구",
  "334:4254": "3_01_borrow_select_계절용품",
  "334:4356": "3_01_borrow_select_생활용품",
  "334:3234": "3_02_borrow_detail01",
  "334:3183": "3_02_borrow_detail02",
  "334:3132": "3_02_borrow_detail03",
  "334:3081": "3_02_borrow_detail04",
  "334:3030": "3_02_borrow_detail05",
  "334:2979": "3_02_borrow_detail06",
  "334:2928": "3_02_borrow_detail07",
  "334:2877": "3_02_borrow_detail08",
  "334:2826": "3_02_borrow_detail09",
  "334:2777": "3_02_borrow_detail10",
  "334:2731": "3_02_borrow_detail11",
  "334:3285": "3_02_borrow_detail12",
  "334:3336": "3_02_borrow_detail13",
  "334:3387": "3_02_borrow_detail14",
  "334:3438": "3_02_borrow_detail15",
  "334:3489": "3_02_borrow_detail16",
  "334:3540": "3_02_borrow_detail17",
  "334:3591": "3_02_borrow_detail18",
  "334:3642": "3_02_borrow_detail19",
  "334:3693": "3_02_borrow_detail20",
  "334:3744": "3_02_borrow_detail21",
  "334:3795": "3_02_borrow_detail22",
  "334:3846": "3_02_borrow_detail23",
  "334:3897": "3_02_borrow_detail24",
  "334:2603": "3_03_borrow_price",
  "334:2694": "3_03"
};

function showScreen(screenName, pushHistory = true) {
  const current = document.querySelector('.screen.active');
  if (current && pushHistory) {
    screenHistory.push(current.dataset.screen);
  }
  document.querySelectorAll('.screen').forEach((s) => s.classList.remove('active'));
  const target = document.querySelector(`[data-screen="${screenName}"]`);
  if (!target) {
    console.error('Screen not found:', screenName);
    return;
  }
  target.classList.add('active');
  const app = document.getElementById('app');
  const h = parseInt(target.dataset.height || '874', 10);
  if (h > 874) app.classList.add('tall');
  else app.classList.remove('tall');
}

function goBack() {
  const previous = screenHistory.pop();
  if (!previous) return;
  document.querySelectorAll('.screen').forEach((s) => s.classList.remove('active'));
  const target = document.querySelector(`[data-screen="${previous}"]`);
  if (target) {
    target.classList.add('active');
    const app = document.getElementById('app');
    const h = parseInt(target.dataset.height || '874', 10);
    if (h > 874) app.classList.add('tall');
    else app.classList.remove('tall');
  }
}

document.addEventListener('click', (event) => {
  const hotspot = event.target.closest('.hotspot');
  if (!hotspot) return;
  const action = hotspot.dataset.action;
  const target = hotspot.dataset.target;
  if (action === 'back') {
    goBack();
    return;
  }
  if (target) showScreen(target);
});

document.addEventListener('DOMContentLoaded', () => {
  showScreen('1_home', false);
});
