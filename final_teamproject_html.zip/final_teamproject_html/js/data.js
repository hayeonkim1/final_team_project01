/**
 * Figma: Final_project_prototype / final_teamproject 3 jw
 * Values from Talk to Figma MCP get_nodes_info
 */

const FRAME = { width: 402, height: 874 };

const CATEGORIES = ['전체', '소형가전', '소형가구', '계절용품', '생활용품'];

const PRODUCTS = [
  {
    id: 'monitor',
    name: '모니터 24인치',
    priceLabel: '월 8,000원 ~',
    basePrice: 8000,
    deposit: 2000,
    category: '소형가전',
    image: 'assets/images/product_monitor.png',
    description: '2023년 구매삼성 갤럭시 모니터 24인치',
    rentalPeriod: '2026.07.15 - 2026.08.15',
    detailPrice: '월 8,000원',
    detailFrameId: '334:2731',
  },
  {
    id: 'fan',
    name: '선풍기(화이트)',
    priceLabel: '월 4,900원 ~',
    basePrice: 4900,
    deposit: 2000,
    category: '계절용품',
    image: 'assets/images/product_fan.png',
    description: '2024년 구매 LG 선풍기 화이트',
    rentalPeriod: '2026.07.01 - 2026.08.01',
    detailPrice: '월 4,900원',
    detailFrameId: '334:2777',
  },
  {
    id: 'chair',
    name: '의자',
    priceLabel: '월 6,000원 ~',
    basePrice: 3900,
    deposit: 2000,
    category: '소형가구',
    image: 'assets/images/product_chair.png',
    description: '2025년 구매 이동식 사무용 의자',
    rentalPeriod: '2026.08.01 - 2027.07.01',
    detailPrice: '월 3,900원',
    detailFrameId: '334:3030',
    displayName: '사무용 의자',
  },
  {
    id: 'carrier',
    name: '캐리어',
    priceLabel: '월 5,900원 ~',
    basePrice: 3000,
    deposit: 2000,
    category: '생활용품',
    image: 'assets/images/product_carrier.png',
    description: '2025년 구매  리틀앤트 28인치 기내용 캐리어',
    rentalPeriod: '2026.07.01 - 2027.07.01',
    detailPrice: '월 3,000원',
    detailFrameId: '334:2826',
    displayName: '캐리어(실버) 28인치',
  },
  {
    id: 'lamp',
    name: '스탠드 조명',
    priceLabel: '월 4,000원 ~',
    basePrice: 3900,
    deposit: 2000,
    category: '생활용품',
    image: 'assets/images/product_lamp.png',
    description: '2026년 구매 장스탠드 조명',
    rentalPeriod: '2026.07.11 - 2026.12.31',
    detailPrice: '월 3,900원',
    detailFrameId: '334:2877',
  },
  {
    id: 'table',
    name: '접이식 테이블',
    priceLabel: '월 7,000원 ~',
    basePrice: 7000,
    deposit: 2000,
    category: '소형가구',
    image: 'assets/images/product_table.png',
    description: '2025년 구매 접이식 테이블',
    rentalPeriod: '2026.07.01 - 2026.08.01',
    detailPrice: '월 7,000원',
    detailFrameId: '334:2979',
  },
  {
    id: 'microwave',
    name: '전자레인지(화이트)',
    priceLabel: '월 4,000원 ~',
    basePrice: 4000,
    deposit: 2000,
    category: '소형가전',
    image: 'assets/images/product_fan.png',
    description: '2024년 구매 전자레인지',
    rentalPeriod: '2026.07.01 - 2026.08.01',
    detailPrice: '월 4,000원',
    detailFrameId: null,
  },
  {
    id: 'mini-fan',
    name: '미니 선풍기',
    priceLabel: '월 1,500원 ~',
    basePrice: 1500,
    deposit: 1000,
    category: '소형가전',
    image: 'assets/images/product_fan.png',
    description: '2025년 구매 미니 선풍기',
    rentalPeriod: '2026.07.01 - 2026.08.01',
    detailPrice: '월 1,500원',
    detailFrameId: null,
  },
  {
    id: 'toaster',
    name: '토스트기(화이트)',
    priceLabel: '월 3,000원 ~',
    basePrice: 3000,
    deposit: 1500,
    category: '소형가전',
    image: 'assets/images/product_lamp.png',
    description: '2024년 구매 토스트기',
    rentalPeriod: '2026.07.01 - 2026.08.01',
    detailPrice: '월 3,000원',
    detailFrameId: null,
  },
];

/** Figma frame id → product id (borrow_select card clicks) */
const CARD_TO_PRODUCT = {
  '334:2731': 'monitor',
  '334:2777': 'fan',
  '334:3030': 'chair',
  '334:2826': 'carrier',
  '334:2877': 'lamp',
  '334:2979': 'table',
};

function formatPrice(n) {
  return `₩${n.toLocaleString('ko-KR')}원`;
}

function getProductsByCategory(category) {
  if (category === '전체') {
    return PRODUCTS.filter((p) =>
      ['monitor', 'fan', 'chair', 'carrier', 'lamp', 'table'].includes(p.id)
    );
  }
  return PRODUCTS.filter((p) => p.category === category);
}

function getProductDisplayName(p) {
  return p.displayName || p.name;
}

function getProductByDetailFrame(frameId) {
  return PRODUCTS.find((p) => p.detailFrameId === frameId);
}
