# -*- coding: utf-8 -*-
import json
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

files = [
    r"C:\Users\ccc\.cursor\projects\c-Users-ccc-Popcorn-Project-Prototype\agent-tools\9565a7df-34e5-4bbd-b2e6-b991033eb7c1.txt",
    r"C:\Users\ccc\.cursor\projects\c-Users-ccc-Popcorn-Project-Prototype\agent-tools\1d70d2d8-ace7-4361-80ca-ea5be11143e2.txt",
    r"C:\Users\ccc\.cursor\projects\c-Users-ccc-Popcorn-Project-Prototype\agent-tools\05b7e9fc-6ac6-4625-8419-c715cd919b6b.txt",
]

SKIP_TEXTS = {
    "대여 가능",
    "전체",
    "소형가전",
    "소형가구",
    "계절용품",
    "생활용품",
    "대여하기",
    "다음",
    "홈",
    "보관 신청",
    "예약/신청",
    "대여",
    "마이페이지",
    "대여할 물품을",
    "선택해주세요",
    "대여 물품 선택",
    "대여 가능한 물품의",
    "상세 설명을 확인해주세요",
    "대여 물품 상세정보",
    "제품 이름",
    "제품 설명",
    "대여 가능 기간",
    "대여 가격",
    "대여 가격 ",
    "보증금",
}


def find_frames(node, pattern, frames=None):
    if frames is None:
        frames = {}
    if isinstance(node, dict):
        name = node.get("name", "")
        if node.get("type") == "FRAME" and pattern in name:
            frames[name] = node
        for child in node.get("children", []):
            find_frames(child, pattern, frames)
    elif isinstance(node, list):
        for item in node:
            find_frames(item, pattern, frames)
    return frames


def collect_texts(node, texts=None):
    if texts is None:
        texts = []
    if isinstance(node, dict):
        if node.get("type") == "TEXT" and "characters" in node:
            bb = node.get("absoluteBoundingBox", {})
            texts.append(
                {
                    "id": node["id"],
                    "text": node["characters"].strip(),
                    "y": bb.get("y", 0),
                    "x": bb.get("x", 0),
                }
            )
        for child in node.get("children", []):
            collect_texts(child, texts)
    return texts


def find_images(node, images=None):
    if images is None:
        images = []
    if isinstance(node, dict):
        fills = node.get("fills", [])
        has_image = any(
            isinstance(f, dict) and f.get("type") == "IMAGE" for f in fills
        )
        # Also check children for INSTANCE rectangles
        if node.get("type") == "INSTANCE":
            for child in node.get("children", []):
                child_fills = child.get("fills", [])
                if any(
                    isinstance(f, dict) and f.get("type") == "IMAGE"
                    for f in child_fills
                ):
                    bb = child.get("absoluteBoundingBox", {}) or node.get(
                        "absoluteBoundingBox", {}
                    )
                    images.append(
                        {
                            "id": child["id"],
                            "instanceId": node["id"],
                            "name": child.get("name", node.get("name", "")),
                            "y": bb.get("y", 0),
                            "x": bb.get("x", 0),
                        }
                    )
        elif has_image and node.get("type") == "RECTANGLE":
            bb = node.get("absoluteBoundingBox", {})
            images.append(
                {
                    "id": node["id"],
                    "instanceId": node["id"],
                    "name": node.get("name", ""),
                    "y": bb.get("y", 0),
                    "x": bb.get("x", 0),
                }
            )
        for child in node.get("children", []):
            find_images(child, images)
    return images


def parse_detail_frame(frame):
    texts = collect_texts(frame)
    images = find_images(frame)

    content = [t for t in texts if t["text"] not in SKIP_TEXTS]
    content_sorted = sorted(content, key=lambda t: (t["y"], t["x"]))

    product_name = None
    description = None
    rental_period = None
    price = None
    deposit = None

    for t in content_sorted:
        txt = t["text"]
        if re.match(r"^\d{4}\.", txt) or re.match(r"^\d{4}\.\d{2}\.\d{2}", txt):
            rental_period = txt
        elif txt.startswith("월 ") and "원" in txt:
            price = txt
        elif txt.startswith("₩") or (txt.endswith("원") and "월" not in txt and "보증" in txt):
            deposit = txt
        elif any(
            kw in txt
            for kw in ["구매", "삼성", "사무", "여행", "LG", "스탠드", "캐리어", "테이블", "의자", "선풍기", "모니터", "이동식", "블루"]
        ) and len(txt) > 10:
            description = txt
        elif product_name is None and len(txt) < 30 and "원" not in txt:
            product_name = txt

    # Deposit: look for text after 보증금 label or ₩ amounts
    for t in texts:
        if t["text"].startswith("₩"):
            if deposit is None:
                deposit = t["text"]
        if "보증금" in t["text"] and t["text"] != "보증금":
            deposit = t["text"]

    # Second pass for deposit in detail frames - look for y > price y
    price_y = next((t["y"] for t in content_sorted if t["text"] == price), 9999)
    for t in content_sorted:
        if t["y"] > price_y and ("원" in t["text"] or "₩" in t["text"]) and t["text"] != price:
            deposit = t["text"]
            break

    img = sorted(images, key=lambda i: (i["y"], i["x"]))
    image_id = img[0]["id"] if img else None

    return {
        "detailFrameId": frame["id"],
        "detailFrameName": frame["name"],
        "productName": product_name,
        "description": description,
        "rentalPeriod": rental_period,
        "price": price,
        "deposit": deposit,
        "imageNodeId": image_id,
        "rawTexts": [t["text"] for t in content_sorted],
    }


def parse_select_frame(frame):
    texts = collect_texts(frame)
    images = find_images(frame)

    # Category from frame name suffix
    frame_name = frame["name"]
    category_from_frame = ""
    if "_전체" in frame_name:
        category_from_frame = "전체"
    elif "_소형가전" in frame_name:
        category_from_frame = "소형가전"
    elif "_소형가구" in frame_name:
        category_from_frame = "소형가구"
    elif "_계절용품" in frame_name:
        category_from_frame = "계절용품"
    elif "_생활용품" in frame_name:
        category_from_frame = "생활용품"

    prices = sorted(
        [t for t in texts if t["text"].startswith("월 ")],
        key=lambda t: (t["y"], t["x"]),
    )
    names = sorted(
        [
            t
            for t in texts
            if not t["text"].startswith("월 ")
            and t["text"] not in SKIP_TEXTS
            and len(t["text"]) < 25
            and "대여" not in t["text"]
            and "선택" not in t["text"]
            and "물품" not in t["text"]
            and "원" not in t["text"]
        ],
        key=lambda t: (t["y"], t["x"]),
    )

    card_images = sorted(images, key=lambda i: (i["y"], i["x"]))

    # Pair names with prices by y proximity
    products = []
    for i, name_t in enumerate(names):
        price_t = prices[i] if i < len(prices) else None
        img = card_images[i] if i < len(card_images) else None

        per_product_category = {
            "모니터 24인치": "소형가전",
            "선풍기(화이트)": "계절용품",
            "의자": "소형가구",
            "캐리어": "생활용품",
            "스탠드 조명": "생활용품",
            "접이식 테이블": "소형가구",
        }

        detail_map = {
            "모니터 24인치": "3-02_borrow_detail11",
            "선풍기(화이트)": "3-02_borrow_detail01",
            "의자": "3-02_borrow_detail02",
            "캐리어": "3-02_borrow_detail03",
            "스탠드 조명": "3-02_borrow_detail04",
            "접이식 테이블": "3-02_borrow_detail05",
        }

        cat = per_product_category.get(name_t["text"], category_from_frame)
        detail_name = detail_map.get(name_t["text"], "")

        products.append(
            {
                "name": name_t["text"],
                "price": price_t["text"] if price_t else None,
                "category": cat,
                "imageNodeId": img["id"] if img else None,
                "detailFrameName": detail_name,
                "selectFrameName": frame_name,
            }
        )

    return products


# Load all data
select_frames = {}
detail_frames = {}
frame_map = {}

for fpath in files:
    with open(fpath, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    for name, frame in find_frames(data, "borrow_select").items():
        select_frames[name] = frame
        frame_map[name] = frame["id"]
    for name, frame in find_frames(data, "borrow_detail").items():
        detail_frames[name] = frame
        frame_map[name] = frame["id"]

# Also add borrow_price from file 1
with open(files[0], "r", encoding="utf-8") as fh:
    data = json.load(fh)
for name, frame in find_frames(data, "borrow_price").items():
    frame_map[name] = frame["id"]
for name, frame in find_frames(data, "3-03").items():
    if frame.get("type") == "FRAME":
        frame_map[name] = frame["id"]

# Parse details
details_by_name = {}
for name, frame in detail_frames.items():
    details_by_name[name] = parse_detail_frame(frame)

# Build detail frame id map
detail_id_map = {name: frame["id"] for name, frame in detail_frames.items()}

# Parse all select products (dedupe by name from 전체 frame)
all_select_products = []
seen = set()
for name in sorted(select_frames.keys()):
    prods = parse_select_frame(select_frames[name])
    for p in prods:
        key = p["name"]
        if key not in seen or name.endswith("전체"):
            if name.endswith("전체") or key not in seen:
                p["detailFrameId"] = detail_id_map.get(p["detailFrameName"])
                # Merge detail info
                detail = details_by_name.get(p["detailFrameName"], {})
                all_select_products.append({**p, **{k: detail.get(k) for k in ["description", "rentalPeriod", "deposit"] if detail.get(k)}})
                seen.add(key)

# Build final products array - one per unique product from 전체 select
products_final = []
select_all = parse_select_frame(select_frames.get("3-01_borrow_select_전체", {}))
if not select_all:
    # fallback: use any select frame
    for name, frame in select_frames.items():
        select_all = parse_select_frame(frame)
        if select_all:
            break

for p in select_all:
    detail_name = p["detailFrameName"]
    detail = details_by_name.get(detail_name, {})
    products_final.append(
        {
            "name": p["name"],
            "price": p["price"],
            "category": p["category"],
            "imageNodeId": p["imageNodeId"],
            "detailFrameId": detail_id_map.get(detail_name),
            "detailFrameName": detail_name,
            "description": detail.get("description"),
            "rentalPeriod": detail.get("rentalPeriod"),
            "detailPrice": detail.get("price"),
            "deposit": detail.get("deposit"),
            "detailImageNodeId": detail.get("imageNodeId"),
        }
    )

output = {
    "frameMap": dict(sorted(frame_map.items())),
    "detailFrames": {name: parse_detail_frame(frame) for name, frame in sorted(detail_frames.items())},
    "selectFrames": {name: parse_select_frame(frame) for name, frame in sorted(select_frames.items())},
    "products": products_final,
}

out_path = r"C:\Users\ccc\Popcorn_Project_Prototype\products_output.json"
with open(out_path, "w", encoding="utf-8") as f:
    json.dump(output, f, ensure_ascii=False, indent=2)

print(json.dumps(output, ensure_ascii=False, indent=2))
